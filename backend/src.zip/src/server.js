const app = require("./app");
const port = process.env.PORT || 8000;

app.listen(port, () => {
  console.log(`Server is running on ${process.env.BACKEND_URL}`);
});
