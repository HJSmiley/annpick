const { indexAnimeData } = require("../src/services/animeService");
require("../src/models/associations");

indexAnimeData();
