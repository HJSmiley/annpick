export const dummyAnimes = [
    { id: 1, title: "도망을 잘 치는 던컨", image: "https://via.placeholder.com/150" },
    { id: 2, title: "전생했더니 슬라임이었단 건에 대하여", image: "https://via.placeholder.com/150" },
    { id: 3, title: "ATRI -My Dear Moments-", image: "https://via.placeholder.com/150" },
    { id: 4, title: "최애의 아이", image: "https://via.placeholder.com/150" },
    { id: 5, title: "이세계 노예 꼬붕", image: "https://via.placeholder.com/150" },
  ];
  export  const dummyAnimes2 = [
    { id: 6, title: "도망을 잘 치는 던컨", image: "https://via.placeholder.com/300x400" },
    { id: 7, title: "전생했더니 슬라임이었단 건에 대하여", image: "https://via.placeholder.com/300x400" },
    { id: 8, title: "ATRI -My Dear Moments-", image: "https://via.placeholder.com/300x400" },
    { id: 9, title: "최애의 아이", image: "https://via.placeholder.com/300x400" },
    { id: 10, title: "이세계 노예 꼬붕", image: "https://via.placeholder.com/300x400" },
  ];
  export const dummyAnimes3 = [
    { id: 11, title: "도망을 잘 치는 던컨", image: "https://via.placeholder.com/300x400" },
    { id: 12, title: "전생했더니 슬라임이었단 건에 대하여", image: "https://via.placeholder.com/300x400" },
    { id: 13, title: "ATRI -My Dear Moments-", image: "https://via.placeholder.com/300x400" },
    { id: 14, title: "최애의 아이", image: "https://via.placeholder.com/300x400" },
    { id: 15, title: "이세계 노예 꼬붕", image: "https://via.placeholder.com/300x400" },
  ];