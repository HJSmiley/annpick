// src/types/anime.ts
export interface Anime {
    id: number;
    title: string;
    image: string;
  }